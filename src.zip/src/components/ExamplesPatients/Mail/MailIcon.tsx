import { memo, SVGProps } from 'react';

const MailIcon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 20 16' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M2 16C1.45 16 0.975 15.8083 0.575 15.425C0.191667 15.025 0 14.55 0 14V2C0 1.45 0.191667 0.983333 0.575 0.599998C0.975 0.199999 1.45 -9.53674e-07 2 -9.53674e-07H18C18.55 -9.53674e-07 19.0167 0.199999 19.4 0.599998C19.8 0.983333 20 1.45 20 2V14C20 14.55 19.8 15.025 19.4 15.425C19.0167 15.8083 18.55 16 18 16H2ZM10 9L18 4V2L10 7L2 2V4L10 9Z'
      fill='#1D1B20'
    />
  </svg>
);

const Memo = memo(MailIcon);
export { Memo as MailIcon };
